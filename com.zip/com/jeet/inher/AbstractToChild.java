package com.jeet.inher;

abstract class AbstractToChild implements Parent
	{

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}
}