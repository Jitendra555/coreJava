package com.jeet.inher;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Test {
	public void disp() throws IOException{}

}
class Child11 extends Test{
	public void disp()throws FileNotFoundException{}
}