package com.jeet.inher;

class Child extends AbstractToChild
{

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		super.m1();
	}
}