package com.jeet.inher;

interface Parent{
	 public void m1();
	 public void m2();
		}
